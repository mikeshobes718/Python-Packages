# __init__.py

# Version of the bryte package
__version__ = "0.0.6"